<?php
			session_start();
			define('DB_SERVER', 'localhost');
		    define('DB_USERNAME', 'root');
		    define('DB_PASSWORD', '');
		    define('DB_DATABASE', 'supervisor');
		    $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
			
   if($_SERVER["REQUEST_METHOD"] == "POST") {
 
	  $username = mysqli_real_escape_string($db,$_POST['email']);
	  $password = mysqli_real_escape_string($db,$_POST['password']);
      $sql = "SELECT * FROM user WHERE email = '$username' and password = '$password'";
      $result = mysqli_query($db,$sql);
	  //$result = mysqli_query($conn, "SELECT id FROM $tb WHERE username = '$username' and pass = '$password' ") or die (mysqli_connect_error());
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      //$active = $row['active'];
      $count = mysqli_num_rows($result);
      // If result matched $username and $password, table row must be 1 row
      if($count==1) {
		 $_SESSION['checkuser']=1;
         $_SESSION['user'] = $username;
        header("location: user_welcome.php");
      }else {
         $message = "Username/Password Invalid.\\nTry again.";
			echo "<script type='text/javascript'>alert('$message');</script>";
      }
   }
   $db->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>User Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
	<link href="front/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <link href="front/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">


  <link href="front/vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">


  <link href="front/css/freelancer.min.css" rel="stylesheet">
<style>
body {
	margin : 0;
	font-family: 'Raleway', sans-serif;
	color : white;
	background-color:#0b2239;
}
.form-detail .register {
	font-family: 'Raleway', sans-serif;
  font-size: 16px;
  color: #fff;
  line-height: 1.2;
  text-transform: uppercase;

  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0 20px;
  width: 30%;
  height: 50px;
  background-color: #3786bd;
  border-radius: 25px;

  box-shadow: 0 10px 30px 0px rgba(0, 0, 0, 0.5);
  -moz-box-shadow: 0 10px 30px 0px rgba(0, 0, 0, 0.5);
  -webkit-box-shadow: 0 10px 30px 0px rgba(0, 0, 0, 0.5);
  -o-box-shadow: 0 10px 30px 0px rgba(0, 0, 0, 0.5);
  -ms-box-shadow: 0 10px 30px 0px rgba(0, 0, 0, 0.5);

  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
  
}
.form-detail .register:hover {
	background-color: #424242;
}
.page-content {
	width: 100%;
	margin:  0;
	background: #fff;
	background-color:#0b2239;
	display: flex;
	display: -webkit-flex;
	justify-content: center;
	-o-justify-content: center;
	-ms-justify-content: center;
	-moz-justify-content: center;
	-webkit-justify-content: center;
	align-items: center;
	-o-align-items: center;
	-ms-align-items: center;
	-moz-align-items: center;
	-webkit-align-items: center;
}
.form-v5-content  {
	background: #f8f9fa;
	width: 670px;
	border-radius: 8px;
	-o-border-radius: 8px;
	-ms-border-radius: 8px;
	-moz-border-radius: 8px;
	-webkit-border-radius: 8px;
	margin: 170px 0;
	font-family: 'Raleway', sans-serif;
	color: #333;
	font-weight: 400;
	position: relative;
	font-size: 18px;
}
.form-v5-content .form-detail {
	padding: 30px 45px 30px 45px;
	position: top;
}
.form-detail h1 {
	color : #fff;
	font-weight: 700;
	font-size: 25px;
	text-align: center;
	position: relative;
	padding: 3px 0 20px;
	margin-bottom: 40px;
}
.form-detail h1::after {
	background: #3786bd;
	width: 50px;
	height: 2px;
	content: "";
	position: absolute;
	top: 100%;
	left: 50%;
    transform: translateX(-50%);
    -o-transform: translateX(-50%);
	-ms-transform: translateX(-50%);
	-moz-transform: translateX(-50%);
	-webkit-transform: translateX(-50%);
}
.form-detail .form-row {
	position: relative;
	color : #fff;
}
.form-detail .form-row-last {
	text-align: center;
	margin-left:230px;
}
.form-detail label {
	display: block;
	font-size: 18px;
	padding-bottom: 10px;
}
.form-detail .input-text {
	margin-bottom: 26px;
}
.form-detail input {
	width: 94.5%;
    padding: 10.5px 15px;
    border: 1px solid #e5e5e5;
    appearance: unset;
    -moz-appearance: unset;
    -webkit-appearance: unset;
    -o-appearance: unset;
    -ms-appearance: unset;
    outline: none;
    -moz-outline: none;
    -webkit-outline: none;
    -o-outline: none;
    -ms-outline: none;
    border-radius: 4px;
	-o-border-radius: 4px;
	-ms-border-radius: 4px;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
	font-family: 'Roboto', sans-serif;
	font-weight: 400;
	font-size: 18px;
}
span {
	color : #3786bd;
}
::placeholder{
	color:white;
}
</style>
</head>
<body class="form-v5">
<!--	<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="index.html">Guwahati Municipal Coorperation</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="f_engg_login.php">Field Engineer</a>
      <a class="nav-item nav-link" href="supervisor_login.php">Supervisor</a>
    </div>
  </div>
</nav>-->
<nav class="navbar navbar-expand-lg bg-light fixed-top text-uppercase text-dark" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger text-dark" href="home.html">GMC</a>
      <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
	 
        <ul class="navbar-nav ml-auto">
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#"></a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger text-dark" href="f_engg_login.php">Field Engineer</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger text-dark" href="supervisor_login.php">Supervisor</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
	<div class="page-content">
		<div class="form-v5-content">
			<form class="form-detail" action="" method="post">
				<h1 class="text-dark">User <span>Login</span></h1>
				<div class="form-row text-dark">
					<label for="email">Email</label>
					<input type="text" name="email" style="background-color:#0b2239; color:white;" id="email" class="input-text" placeholder="Email" required pattern="[^@]+@[^@]+.[a-zA-Z]{2,6}" >
					
				</div>
				<div class="form-row text-dark">
					<label for="password">Password</label>
					<input type="password" style="background-color:#0b2239; color:white;" name="password" id="password" class="input-text" placeholder="Password" required>
				</div>
				<div class="form-row-last">
					<input type="submit" name="register" class="register" value="Login">
				</div>
			</form>
		</div>
	</div>
	<!-- Bootstrap core JavaScript -->
  <script src="front/vendor/jquery/jquery.min.js"></script>
  <script src="front/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="front/vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="front/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

  <!-- Contact Form JavaScript -->
  <script src="front/js/jqBootstrapValidation.js"></script>
  <script src="front/js/contact_me.js"></script>

  <!-- Custom scripts for this template -->
  <script src="front/js/freelancer.min.js"></script>
</body>
</html>