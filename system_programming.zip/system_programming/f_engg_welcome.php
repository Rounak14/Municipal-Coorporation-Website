<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Welcome</title>
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<style>
body {
	font-family: 'Raleway', sans-serif;
}
.form-detail h1 {
	color : black;
	font-weight: 700;
	font-size: 40px;
	text-align: center;
	position: relative;
	padding: 3px 0 20px;
	margin-bottom: 40px;
}
.form-detail h1::after {
	background: #3786bd;
	width: 50px;
	height: 2px;
	content: "";
	position: absolute;
	top: 100%;
	left: 50%;
    transform: translateX(-50%);
    -o-transform: translateX(-50%);
	-ms-transform: translateX(-50%);
	-moz-transform: translateX(-50%);
	-webkit-transform: translateX(-50%);
}
</style>
</head>
<body class="form-v5">
	<div class="page-content">
		<div class="form-v5-content">
			<div class="form-detail">
				<h1>Welcome</h1>
			</div>
		</div>
	</div>
	

</body>
</html>