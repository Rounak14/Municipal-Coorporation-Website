<!DOCTYPE html>
<html lang="en">
<head>
	<title>Complaint Booking</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
    integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<style>
@media screen and (max-width: 767px) {
	.form-v5-content {
	    margin: 175px 20px;
	}
}
body {
	margin : 0;
	font-family: 'Raleway', sans-serif;
}
body {
      background-color: #0b2239;
    }
    .jumbotron {
      margin: 200px;
      margin-top: 50px;
    }
    h1{
      font-size: 2em;
	  text-align: center;
    }
	button{
		background-color: #477faa;
	}
	.time {
		align : right;
	}
	button {
		background-color : skyblue;
		position:relative;
		transition: .5s ease;
		top: 10px;
		left: 265px;
	}
	span{
		color : #3786bd;
	}
</style>
<body>
<div class="container">
      <div class="jumbotron">
			<h1><strong> Complaint <span>Registration<span></strong></h1>
			</br>
			</br>
			<form class="form-group" action="" method="POST">
			<input class="form-control" type="text" name="name" value="" placeholder="Full name" required>
			</br>
			<input class="form-control" type="text" name="mobile" value="" maxlength="10" placeholder="Mobile Number (*Only 10 digits)" required>
			</br>
			<input class="form-control" type="email" name="email" value="" placeholder="E-mail" required>	
			</br>
			<input class="form-control" type="text" name="location" value="" placeholder="Location" required>	
			</br>
		
			<strong>Department:<strong>
			</br>
			
			<select class="form-control" name="department" required>
				<option value="0">Not selected</option>
				<option value="Water Supply">Water Supply</option>
				<option value="Road Management ">Road Management </option>
				<option value="Sewage & Waste Management">Sewage & Waste Management</option>
			</select>
			</br>
			<strong> *Select Complaint from chosen Department only</strong>
			</br>
			</br>
			<strong>Complaints</strong>
			</br>
			<select class="form-control" name="complaint" required>
				<option value="0">Not selected</option>
				<option>WATER COMPLAINTS-----------------------------------------------------------------------------------</option>
				<option value="Pipeline Blockage">Pipeline Blockage</option>
				<option value="Pipeline Leakage">Pipeline Leakage </option>
				<option> &nbsp;     </option>
				<option>ROAD COMPLAINTS-----------------------------------------------------------------------------------</option>
				<option value="Potholes">Potholes</option>
				<option value="Cleaning">Cleaning  </option>
				<option value="Reconstruction ">Reconstruction </option>
				<option value="Speed breaker">Speed breaker  </option>
				<option> &nbsp;     </option>
				<option>SEWAGE AND WASTE MANAGEMENT-----------------------------------------------------------------------</option>
				<option value="t Manhole ">Manhole </option>
				<option value="Drainage Leakage">Drainage Leakage </option>
				<option value="Drainage Cleaning ">Drainage Cleaning </option>
				<option value="Drainage Repair">Drainage Repair </option>
				<option value="Dead Animal ">Dead Animal  </option>
				<option value="Dustbin installation ">Dustbin installation  </option>
			</select>
			
        <!--<input  type="submit" name="submit">-->
		<button type="submit" class="btn btn-primary">Submit</button>
		</form>
    </div>
</div>
<?php


			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "supervisor";

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 
		
		
		if(!empty($_POST))
		{
			$name=$_POST['name'];
			$email=$_POST['email'];
			$mobile=$_POST['mobile'];
			$location=$_POST['location'];
			$dept=$_POST['department'];
			$complaint=$_POST['complaint'];
			$sql = "INSERT INTO complaint (name, mobile , email, dept, complaint,location)
			VALUES ('$name','$mobile','$email','$dept','$complaint','$location')";
			
			if ($conn->query($sql) === TRUE) {
			} else {
				echo "Error: " . $sql . "<br>" . $conn->error;
			}
			$message = "Complaint Registered Successfully";
			echo "<script type='text/javascript'>alert('$message');</script>";
			header("Location: user_welcome.php");
		}
		else
		{
			$message = "Unsuccessful!, Try again";
			echo "<script type='text/javascript'>alert('$message');</script>";
		}
		
		$conn->close();	
	?>
</body>
</html>