-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2019 at 07:53 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supervisor`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `email` varchar(150) NOT NULL,
  `dept` text NOT NULL,
  `complaint` text NOT NULL,
  `location` text NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Pending',
  `allot` int(10) NOT NULL DEFAULT '0',
  `super_status` varchar(100) NOT NULL DEFAULT 'Pending',
  `tcid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`id`, `name`, `mobile`, `email`, `dept`, `complaint`, `location`, `status`, `allot`, `super_status`, `tcid`) VALUES
(1, 'akash gupta', 9856321472, 'akash@gmail.com', 'Water Supply', 'Pipeline Blockage', '', 'Approved', 3, 'Done', ''),
(3, 'rounak parihar', 8402803233, 'rouna170101056@iitg.ac.in', 'Sewage & Waste Management', 'Drainage Cleaning ', 'Panbazar', 'Approved', 5, 'Done', ''),
(4, 'aman', 4816161616, 'amanjn315@gmail.com', 'Water Supply', 'Pipeline Leakage', 'fancy bazar', 'Approved', 0, 'Rejected', ''),
(5, 'rounak parihar', 8402803233, 'rouna170101056@iitg.ac.in', 'Road Management ', 'Speed breaker', 'dede', 'Approved', 0, 'Done', ''),
(6, 'rounak parihar', 8402803233, 'rouna170101056@iitg.ac.in', 'Road Management ', 'Speed breaker', 'ecfe4f', 'Approved', 0, 'Done', 'Sng6DETm4Z'),
(7, 'rounak parihar', 8402803233, 'rouna170101056@iitg.ac.in', 'Road Management ', 'Reconstruction ', 'melmfofo4', 'Pending', 0, 'Pending', '');

-- --------------------------------------------------------

--
-- Table structure for table `completed`
--

CREATE TABLE `completed` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dept` text NOT NULL,
  `complaint` text NOT NULL,
  `location` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `field`
--

CREATE TABLE `field` (
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `field`
--

INSERT INTO `field` (`name`, `email`, `password`) VALUES
('Rutvik Ghughal', 'rutvik@gmail.com', 'rutvik');

-- --------------------------------------------------------

--
-- Table structure for table `supervisor`
--

CREATE TABLE `supervisor` (
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supervisor`
--

INSERT INTO `supervisor` (`name`, `email`, `password`) VALUES
('Rounak Parihar', 'pariharrounak@gmail.com', 'rounak');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` text NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `email`, `password`) VALUES
('akash gupta', 'akash@gmail.com', 'akash'),
('Rounak Parihar', 'rouna170101056@iitg.ac.in', 'rounak'),
('aman jain', 'amanjn315@gmail.com', 'aman');

-- --------------------------------------------------------

--
-- Table structure for table `workers`
--

CREATE TABLE `workers` (
  `dept` text NOT NULL,
  `complaint` text NOT NULL,
  `total` int(100) NOT NULL,
  `worker_left` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workers`
--

INSERT INTO `workers` (`dept`, `complaint`, `total`, `worker_left`) VALUES
('Water Supply', 'Pipeline Blockage', 5, 5),
('Water Supply', 'Pipeline Leakage', 3, 3),
('Road Management', 'Potholes', 7, 7),
('Road Management', 'Cleaning', 3, 3),
('Road Management', 'Reconstruction', 20, 20),
('Road Management', 'Speed breaker', 5, 5),
('Sewage & Waste Management ', 'Manhole', 5, 5),
('Sewage & Waste Management ', 'Drainage Leakage ', 10, 10),
('Sewage & Waste Management ', 'Drainage Cleaning', 7, 7),
('Sewage & Waste Management ', 'Drainage Repair', 10, 10),
('Sewage & Waste Management ', 'Dead Animal', 4, 4),
('Sewage & Waste Management ', 'Dustbin installation', 6, 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaint`
--
ALTER TABLE `complaint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `completed`
--
ALTER TABLE `completed`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaint`
--
ALTER TABLE `complaint`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `completed`
--
ALTER TABLE `completed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
