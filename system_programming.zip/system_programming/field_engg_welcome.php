<?php

		session_start();
		if($_SESSION['check']==1)
		{
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "supervisor";
		
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {

			die("Connection failed: " . $conn->connect_error);
		}
		if(isset($_POST['approve']))
		{
			$status="Approved";
			$id=$_POST['id'];
			$mail=$_POST['email'];
			$query="UPDATE `complaint` set `status`='$status' where `id`=$id";
			$res=mysqli_query($conn,$query);
			
			if( mail($mail,'Approval','hello, your request is approved by Field Engineer and forwarded to Supervisor. Once Supervisor approves the request we will Inform you!') ) {
            echo "Message sent successfully...";
			}else {
            echo "Message could not be sent...";
			}
		}
		if(isset($_POST['reject']))
		{
			$status="Rejected";
			$id=$_POST['id'];
			$mail=$_POST['email'];
			$query="UPDATE `complaint` set `status`='$status' where `id`=$id";
			$res=mysqli_query($conn,$query);
			
			if( mail($mail,'Approval','hello, your request is Rejected by Field Engineer, Please try again with some proper details.') ) {
				echo "Message sent successfully...";
				}else {
				echo "Message could not be sent...";
				}
		}
		}
		if($_SESSION['check']!=1||isset($_POST['logout']))
		{
			session_destroy();
			header("Location: f_engg_login.php");
		}
	
		?>
				

<!doctype html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <title>Field engg Dashboard</title>
    <link href="./assets/css/dashboard.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="front/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <link href="front/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Nunito+Sans" rel="stylesheet">

  <link href="front/vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">


  <link href="front/css/freelancer.min.css" rel="stylesheet">
	<style>
.w3-lobster {
  font-family: "Lobster", serif;
}

body{
	background-color:#f66d3b;
}
h1{
	font-family: 'Lato', sans-serif;
}
.btn{
	background: rgb(28, 184, 65);
}
.btn:hover{
	background-color:#18bc9c;
}
h2{
	font-family: 'Nunito Sans', sans-serif;
}

</style>
  </head>
	<body>
	  

<nav class="navbar navbar-expand-lg bg-dark fixed-top text-light" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger text-light" href="#"><?php
			echo "WELCOME &nbsp;&nbsp;";
			echo $_SESSION['username'];
		?></a>
      <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
	 
        <ul class="navbar-nav ml-auto">
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#"></a>
          </li>
		  <li><div class="nav-item mx-0 mx-lg-1 collapse navbar-collapse">
				<form class="form-inline my-2 my-lg-0" method="post">
					<button class="btn btn-primary" name="logout" type="submit">Logout</button>
				</form>
			</div>
		  </li>
        </ul>
      </div>
    </div>
  </nav>
</br>
</br>
</br>
</br>
</br>
        <h1 class="w3-container text-uppercase" align="center">Field Engineer</h1>
		</br>
		<h2 class="w3-container text-light">Complaints</h2>
		<table class="table table-hover table-dark w3-animate-bottom">
		<thead class="thead-light">
		<tr>
                <th>Number</th>
				<th>Name</th>
				<th>Mobile Number</th>
				<th>Email</th>
				<th>Department</th>
				<th>Complaint</th>
				<th>Location</th>
				<th>Status</th>
				<th>Alloted Workers</th>
				<th>Supervisor Status</th>
				<th>Response</th>
				</tr>
			</thead>
		<tbody>
	
		<?php 
			
				$query = "SELECT * FROM complaint";
				if (!$result = mysqli_query($conn, $query)) {
					exit(mysqli_error($conn));
				}

				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_assoc($result))
					{
						?>
						<td><?php echo $row['id'];?></td>
						 <td><?php echo $row['name'];?></td>
						 <td><?php echo $row['mobile'];?></td>
						 <td><?php echo $row['email'];?></td>
						 <td><?php echo $row['dept'];?></td>
						 <td><?php echo $row['complaint'];?></td>
						 <td><?php echo $row['location'];?></td>
						 <td><?php echo $row['status'];?></td>
						 <td><?php echo $row['allot'];?></td>
						 <td><?php echo$row['super_status'];?></td>
						 <td><form action="" method="post">
						 <input type="hidden" name="id" value="<?php echo $row['id'];?>">
						 <input type="hidden" name="email" value="<?php echo $row['email'];?>">
								<button type = "submit" name="approve" <?php echo ($row['status']=="Approved"||$row['status']=="Rejected") ? 'disabled="true"' : ''; ?> class="btn btn-primary">Approve</button>      
								<button type = "submit" name="reject" <?php echo ($row['status']=="Approved"||$row['status']=="Rejected") ? 'disabled="true"' : ''; ?> class="btn btn-primary">Reject</button>
							</form>
						</td>
						</tr>
					<?php
					}
				}
				else
				{
					
				}
				?>
		</tbody>
		</table>

<?php

?>
			<!-- Bootstrap core JavaScript -->
  <script src="front/vendor/jquery/jquery.min.js"></script>
  <script src="front/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="front/vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="front/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

  <!-- Contact Form JavaScript -->
  <script src="front/js/jqBootstrapValidation.js"></script>
  <script src="front/js/contact_me.js"></script>

  <!-- Custom scripts for this template -->
  <script src="front/js/freelancer.min.js"></script>
 </body>
</html>