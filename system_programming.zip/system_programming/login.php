
<!DOCTYPE html>
<html lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="shortcut icon" href="https://media.flaticon.com/img/favicon.ico">
	<title>Login</title>

	
		<link href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,700italic,400,600,700' rel='stylesheet' type='text/css'>
	
	<script>
	</script>

	<link rel='stylesheet' href='https://fiprofile.cdnpk.net/css/profile.css?key=21155485b113de7bc66e08028c330bc72019043017'>
	<script defer src='https://www.flaticon.com/profile/titan/selector'></script>

			
	<script src='https://fiprofile.cdnpk.net/js/vendors.js?key=fa3247dcc99ba29c02a7c88c18dead092019043017'></script>
    <script src="//cdn.ravenjs.com/3.9.1/raven.min.js" crossorigin="anonymous"></script>
   
	
	</head>

<body class="flaticon bg-login">
	
<script type='text/javascript' src='//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js'></script>	<script src='https://fiprofile.cdnpk.net/js/bundle.js?key=cf8eb3f08da42eddeb27391f744af6502019043017'></script>
	
	<div class="header-projects">
		<a href="https://www.freepik.com" target="_blank">
			
		</a>
		<a href="https://www.flaticon.com" target="_blank">
			
		</a>
		<a href="https://www.tutpad.com" target="_blank">
			
		</a>
	</div>

	<script src="https://www.google.com/recaptcha/api.js?hl=en"></script>
	<section id="gr_loginbox" class="gr_box login nolo_anime" style="display: block;">
	<div class="box__holder">
		
		<h1 class="terms-of-service">User Login</h1>
		<div class="box">

			<form method="post">
				<span class="input-group to_be_hidden">
					<input type="email" name="email" id="gr_login_username" required tabindex="1" autocomplete="off" autofocus autocapitalize="off" autocorrect="off" />
					<label for="gr_login_username">Username or email</label>
					<a href="javascript:void(0);" class="reset-input">&times;</a>
				</span>

				<span class="input-group to_be_hidden">
					<input type="password" name="password" id="gr_login_password" required tabindex="2" autocomplete="off" autocapitalize="off" autocorrect="off" />
					<label for="gr_login_password">Password</label>
					<a href="javascript:void(0);" class="reset-input">&times;</a>
				</span>

				<div id="gr_login_recaptcha_container" wid=""></div>

				<p class="to_be_shown" style="display: none;">Checking your credentials...</p>

				<button class="btn fullwidth spinner_button" id="signin_button" tabindex="3">Sign in</button>
			</form>
			<div class="bottom-links">
				<a href="usersignup.php" class="href-sign-up" onclick="gr.auth.register_form();">Not a member? Sign up</a>
			</div><!-- .bottom-links -->
		</div><!-- .box -->
	</div><!-- .box__holder -->
</section><!-- #login -->
	<div class="modal">
		<input class="modal-state" id="modal" type="checkbox" />
		<div class="modal-window">
			<div class="modal-inner">
				<label class="modal-close" for="modal"></label>
				<div id="modal-container"><iframe id="modal-iframe" src="javascript:;"></iframe></div>
			</div>
		</div>
	</div>
	</body>
</html>